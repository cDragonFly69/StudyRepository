# ubuntu关于mysql

ubuntu安装mysql5.6遇到的问题以及解决方案：

2.2.1 用apt进行安装
前面尝试着使用过下载TAR包然后手动安装的方法，但是报错层出不穷，一直都没有解决，所有最后还是决定使用apt来安装。

首先要添加源，如果没有加这几个源，会报错找不到Initscripts这个问题。

sudo vim /etc/apt/sources.list

# 清华镜像源

deb [https://mirrors.tuna.tsinghua.edu.cn/ubuntu/](https://mirrors.tuna.tsinghua.edu.cn/ubuntu/) xenial main restricted universe multiverse

deb-src [https://mirrors.tuna.tsinghua.edu.cn/ubuntu/](https://mirrors.tuna.tsinghua.edu.cn/ubuntu/) xenial main restricted universe multiverse

deb [https://mirrors.tuna.tsinghua.edu.cn/ubuntu/](https://mirrors.tuna.tsinghua.edu.cn/ubuntu/) xenial-updates main restricted universe multiverse

deb-src [https://mirrors.tuna.tsinghua.edu.cn/ubuntu/](https://mirrors.tuna.tsinghua.edu.cn/ubuntu/) xenial-updates main restricted universe multiverse

deb [https://mirrors.tuna.tsinghua.edu.cn/ubuntu/](https://mirrors.tuna.tsinghua.edu.cn/ubuntu/) xenial-backports main restricted universe multiverse

deb-src [https://mirrors.tuna.tsinghua.edu.cn/ubuntu/](https://mirrors.tuna.tsinghua.edu.cn/ubuntu/) xenial-backports main restricted universe multiverse

deb [https://mirrors.tuna.tsinghua.edu.cn/ubuntu/](https://mirrors.tuna.tsinghua.edu.cn/ubuntu/) xenial-security main restricted universe multiverse

deb-src [https://mirrors.tuna.tsinghua.edu.cn/ubuntu/](https://mirrors.tuna.tsinghua.edu.cn/ubuntu/) xenial-security main restricted universe multiverse

添加源之后，使用命令sudo apt-get install mysql-server-5.6安装5.6的服务器部分。

然后安装命令：sudo 

——————————————-分割线—————————————

mysql命令：sudo apt install mysql-server-5.6

启动mysql：sudo service mysql start

重启mysql: sudo service mysql restart

停止mysql：sudo service mysql stop

进入mysqlshell：mysql -u root -p

具体操作：

安装mysql5.6在ubuntu上安装mysql5.6的版本

1.添加mysql5.6的源

`sudo apt-get install software-properties-common
sudo add-apt-repository 'deb http://archive.ubuntu.com/ubuntu trusty universe'`

2.安装mysql5.6

`sudo apt-get update
sudo apt install mysql-server-5.6
sudo apt install mysql-client-5.6`

安装mysql server的时候需要手动配置root密码：

![https://img2020.cnblogs.com/i-beta/1294418/202003/1294418-20200317142849970-439924678.png](https://img2020.cnblogs.com/i-beta/1294418/202003/1294418-20200317142849970-439924678.png)

3.设置开机自启

`update-rc.d mysql defaults`

4.创建或修改 my.cnf 文件在/etc/mysql/目录下添加 my.cnf文件

`sudo vim /etc/mysql/my.cnf`

复制下面的内容，并保存文件

`# The MySQL database server configuration file.
#
# You can copy this to one of:
# - "/etc/mysql/my.cnf" to set global options,
# - "~/.my.cnf" to set user-specific options.
#
# One can use all long options that the program supports.
# Run program with --help to get a list of available options and with
# --print-defaults to see which it would actually understand and use.
#
# For explanations see
# http://dev.mysql.com/doc/mysql/en/server-system-variables.html

# This will be passed to all mysql clients
# It has been reported that passwords should be enclosed with ticks/quotes
# escpecially if they contain "#" chars...
# Remember to edit /etc/mysql/debian.cnf when changing the socket location.

# Here is entries for some specific programs
# The following values assume you have at least 32M ram

!includedir /etc/mysql/conf.d/
# add here
[mysqld]
default-time_zone = '+8:00'
lower_case_table_names=1`

5.重启Mysql服务

`sudo service mysql restart`

**启动/停止 Mysql**

```
> sudo /etc/init.d/mysql start

> sudo /etc/init.d/mysql stop

```

具体链接：

[ubuntu安装mysql5.6 - 疯刘小三 - 博客园 (cnblogs.com)](https://www.cnblogs.com/Crazy-Liu/p/12510551.html)