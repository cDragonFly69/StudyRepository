# Linux

[ ubuntu关于mysql](Linux%20762c067a2b4a404aa097af8e5f27ebec/ubuntu%E5%85%B3%E4%BA%8Emysql%20bb875b2b1e8345e2a3c95aec2556c988.md)

[HBbase](Linux%20762c067a2b4a404aa097af8e5f27ebec/HBbase%20f9d116fc2c4d4c5ba314e39707628189.md)

[搭建Hadoop集群](Linux%20762c067a2b4a404aa097af8e5f27ebec/%E6%90%AD%E5%BB%BAHadoop%E9%9B%86%E7%BE%A4%204efabe8f9e7142ce8308354861d16e67.md)

- Linux基本命令
    - 重启系统：shutdown -h now 或poweroff
    - 两分钟后重启；shutdown -r 2
    - 帮助命令：help
    - 命令说明书：man
    - 切换用户：su
    - 切换目录：cd
    - 查看目录：ls
    - 创建目录：mkdir
    - 删除目录与文件：rm
    - 修改目录：mv
    - 拷贝目录：cp
    - 搜索目录：find
    - 查看当前目录：pwd
    - 新增文件：touch
    - 删除文件：rm
    - 编辑文件：vi，vim
    - 查看文件：cat，less，more，tail
    - 文件权限：chmod
    - 打包与解压：打包：tar -zcvf 解压：tar -zxvf
    - whereis ls：将和ls文件相关的文件都查找出来。
    - which：查看在环境变量$PATH设置的目录里查找符合条件的文件。
    - sudo： 系统管理员身份执行命令
    - grep：查找命令
    - service：对系统服务的启动、停止、重启、状态查询等操作
    - free：查看显示系统当前内存的使用情况，包括可用内存、可用内存和交换内存的情况。
    - top：显示当前系统中占用资源最多的一些进程
    - df：显示文件系统的磁盘使用情况
    - mount：将文件挂载到指令的挂载点上
    - uname：可以显示一些重要的系统信息
    - yum：安装插件命令
    - rpm：插件安装命令
    - date：显示当前的日期和时间
    - wget：使用wget从网上下载软件
    - ftp：访问ftp服务器。
    - ifconfig：查看网络
    - 查看进程：ps
    - 结束进程：kill
    - 查看链接：ping ip//查看榆次ip地址的连接情况，netstat -an查看当前系统端口
    - ctrl+l：快速清屏
    - 远程主机㊙️ ip
    -