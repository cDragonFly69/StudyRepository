# docker

[day02-Docker.pdf](docker%20e2ace7d6af2149e7b95970e50be9dcca/day02-Docker.pdf)

docker基本命令：

- 把docker当成一个容器：
    
    
- 安装docker的命令：curl -fsSL [https://get.docker.com](https://get.docker.com/) | bash -s docker --mirror Aliyun
- 查询docker的版本命令：docker —verison
- 启动dokcer：sudo systemctl start docker
- 拉取并运行helloworld镜像来验证是否正确安装docker
1. //拉取镜像：sudo docker pull hello-world
2. //执行hello-world：sudo docker run hello-world
- 守护进程重启:systemctl daemon-reload
- 重启Docker服务：systemctl restart docker / service docker restart
- 关闭Docker服务:docker service docker stop / docker systemctl stop docker
- 卸载Docker软件包：sudo apt-get purge docker-ce
- 删除Docker数据和配置文件（谨慎操作）：sudo rm -rf /var/lib/docker

安装镜像加速器：

您可以通过修改daemon配置文件/etc/docker/daemon.json来使用加速器

```
sudo mkdir -p /etc/docker
sudo tee /etc/docker/daemon.json <<-'EOF'
{
  "registry-mirrors": ["https://mqqeorws.mirror.aliyuncs.com"]
}
EOF
sudo systemctl daemon-reload
sudo systemctl restart docker
```

### 

## docker操作镜像、容器的命令：

### dokcer run命令中的常用参数:

- -d:让容器后台运行
- —name:给容器命名
- -e:环境变量
- -p:宿主机端口映射到容器内端口
- 镜像名称结构：repository：TAG —>镜像名：版本
- docker run命令和docker start的区别：
    - docker run 是指创建一个新的容器并执行
    - docker start 是指创建好的容器停止了，需要用start重启即可
1. docker pull:拉取
2. docker push:推送
3. docker ps：查看docker进程。
4. 将一个镜像打包：docker save -o nginx.tar nginx:latest
5. 将已打包的镜像包加载出来：docker load -i nginx.tar

docker ps —format “table {{.ID}}\t{{.Image}}\t{{.Ports}}\t{{.Status}}\t{{.Names}}” //查看正在运行的容器

docker ps —format “table {{.ID}}\t{{.Image}}\t{{.Ports}}\t{{.Status}}\t{{.Names}}” -a //查看所有的容器

### 什么是数据卷？

- 数据卷是一个虚拟目录，它将宿主机目录映射到容器内目录，方便我们操作容器内文件，或者方便迁移容器产生的数据

### 如何挂载数据卷？

- 在创建容器时，利用-v数据卷名：容器内目录完成挂载
- 容器创建时，如果发现挂载的数据卷不存在时，会自动创建

### 数据卷常用命令有哪些

- docker volume ls:查看数据卷
- docker volume rm:删除数据卷
- docker volume inspect:查看数据卷详情
- docker volume prune:删除未使用的数据卷